import os
import time
import sys
# Set color
G = '\033[1;32m' # Green

def delay_print(s):
    for c in s:
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.003)
delay_print
delay_print (""+G+"╔════════════════════════════════════════╗  ""\n")
delay_print (""+G+"║ Instagram: @ 0R2Mstore.id0                ║  ""\n")
delay_print (""+G+"║ Github: https://github.com/RXCODE-C2/ ║  ""\n")
delay_print (""+G+"╚════════════════════════════════════════╝  ""\n")
